package com.example.hms.ModelClass;

public class RoomMode {
    String RoomNumber;

    public RoomMode() {
    }

    public RoomMode(String roomNumber) {
        RoomNumber = roomNumber;
    }

    public String getRoomNumber() {
        return RoomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        RoomNumber = roomNumber;
    }
}
