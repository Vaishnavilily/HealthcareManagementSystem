package com.example.hms.ReceptionStaff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hms.R;

public class ViewSalary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_salary);
    }
}
